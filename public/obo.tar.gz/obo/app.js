// UserMedia

var userMedia = undefined;
navigator.getUserMedia = navigator.getUserMedia
|| navigator.webkitGetUserMedia
|| navigator.mozGetUserMedia
|| navigator.msGetUserMedia;


if(!navigator.getUserMedia){
    console.error("No getUserMedia Support in this Browser");
}

navigator.getUserMedia({
    audio:true
}, function(stream){
    userMedia = stream;
}, function(error){
    console.error("Could not get User Media: " + error);
});

if(window.location.protocol === 'file:'){
    $("#content").hide();
    $("#error").show();
} else {
    $("#error").hide();
    // INIT
    Nuance.logger = {
        log: function(msg){
            LOG(msg, 'out');
        }
    };
    // TABS init
    var hash = window.location.hash;
    hash && $('ul.nav a[href="' + hash + '"]').tab('show');
    $(document).on('shown.bs.tab', function(event) {
      window.location.hash = $(event.target).attr('href');
    });
}

// State

var isRecording = false;

// Selectors

var $content = $('#content');
var $url = $('#url');
var $appKey = $('#app_key');
var $appId = $('#app_id');
var $userId = $('#user_id');
var $nluTag = $('#nlu_tag');
var $language = $('#language');
var $saveCreds = $("#save_creds");
var $resetCreds = $("#reset_creds");
var $useNlu = $("#use_nlu");
var $ttsGo = $('#tts_go');
var $ttsText = $('#tts_text');
var $ttsDebug = $('#tts_debug_output');
var $asrRecord = $('#asr_go');
var $asrLabel = $('#asr_label');
var $nluExecute = $('#nlu_go');
var $asrDebug = $('#asr_debug_output');
var $nluDebug = $('#nlu_debug_output');
var $showHideToggle = $('#show-hide-credentials');

$showHideToggle.on('click', function(){
    var cv = $("#credentials-view");
    if(cv.is(':visible')){
        $(this).text('Show');
    } else {
        $(this).text('Hide');
    }
    cv.toggle();
});

// Default options for all transactions

var defaultOptions = {
    onopen: function() {
        $content.addClass('connected');
    },
    onclose: function() {
        $content.removeClass('connected');
    },
    onvolume: function(vol) {
    },
    onresult: function(msg) {
        LOG(msg, 'in');
        if (msg.result_type === "NMDP_TTS_CMD" || msg.result_type === "NVC_TTS_CMD") {
            dLog(JSON.stringify(msg, null, 2), $ttsDebug);
            $ttsGo.prop('disabled', false);
        } else if (msg.result_type === "NVC_ASR_CMD") {
            //RESPONSE FROM TEXT TO SPEECH
            var spoken = msg.transcriptions[0];
            textNlu(spoken);
            dLog(JSON.stringify(msg, null, 2), $asrDebug);
        } else if (msg.result_type == "NDSP_ASR_APP_CMD") {
            if(msg.result_format === "nlu_interpretation_results") {
            } else {
                setTimeout(function m(){tts("Sorry, that didn't work out. Please try again, error 2.");}, 500)
            }
            $nluExecute.prop('disabled', false);
        } else if (msg.result_type === "NDSP_APP_CMD") {
            if(msg.result_format === "nlu_interpretation_results") {
                var value = msg.nlu_interpretation_results.payload.interpretations[0].action.intent.value;
                var confidence = msg.nlu_interpretation_results.payload.interpretations[0].action.intent.confidence;
                var literal = msg.nlu_interpretation_results.payload.interpretations[0].literal;
		
                //window.pr_manager.set(new Date(), window.CONTEXT.speed());
		
                if(confidence < 0.40){
                    setTimeout(function m(){tts("I heard: "+literal+". But, I don't know what that means.");}, 500)
                }else if(value == 'read_full_page' || value == 'read_selection' || value == 'read_until_end'){
                    performFunction(value, startReading);
                }else if(value =='read_from_text'){
                    var htmlObject = document.createElement('div');
                    htmlObject.innerHTML = document.body.innerHTML;
                    var myJson = addList(htmlObject.children);
                    var searchText= literal.substring(literal.indexOf("from")+5).toLowerCase();
                    console.log("searchText: "+searchText);
                    var newMyJson = [];
                    var found = false;
                    for (var i = 0; i < myJson.length; i++) {
                        if(found){
                            newMyJson.push(myJson[i]);
                        }else{
                            var text = myJson[i][Object.keys(myJson[i])];
                            if(text.toLowerCase().indexOf(searchText) != -1){
                                myJson[i][Object.keys(myJson[i])] = text.substring(text.indexOf(searchText))
                                newMyJson.push(myJson[i]);
                                found = true;
                            }
                        }
                    }
                    if(newMyJson.length == 0){
                        setTimeout(function m(){tts("No text was found to speed read.");}, 250)
                    }else{
                        window.CONTEXT.read(newMyJson);
                    }
                    console.log(newMyJson);
                }else if(value =='play' || value =='pause'){
                    if(window.CONTEXT != null && window.CONTEXT.showing()){
                        window.CONTEXT.play();
                    }else{
                        setTimeout(function m(){tts("What part would you like me to start");}, 500)
                    }
                }else if(window.CONTEXT != null){
                    if(value =='restart'){
                        window.CONTEXT.prev();
                        window.pr_manager.set(new Date(), window.CONTEXT.speed());
                    }else if(value =='skip'){
                        setTimeout(function m(){tts("If I could I would make it skip now");}, 500)
                    }else if(value =='close'){
                        window.CONTEXT.hide();
                    }else if(value =='speed_up'){
                        setTimeout(function m(){tts("If I could I would make it speed up now");}, 500)
                    }else if(value =='slow_down'){
                        setTimeout(function m(){tts("If I could I would make it slow down now");}, 500)
                    }else if(value =='open_analytics'){
			var win = window.open("http://proread.tech:8081/", '_blank');
			win.focus();
                    }else if(value =='open_settings'){
                        window.CONTEXT.settings();
                    }else {
                        setTimeout(function m(){tts("I heard: "+literal+". But, I don't know what that means.");}, 500)
                    }
                }else {
                    setTimeout(function m(){tts("I heard: "+literal+". But, I don't know what that means.");}, 500)
                }
            } else {
                setTimeout(function m(){tts("Sorry, that didn't work out. Please try again, error 3.");}, 500)
            }
        }
    },
    onerror: function(error) {
        setTimeout(function m(){tts("An error occured, see console for more detail");}, 500)
        console.error(error);
    }
};

function createOptions(overrides) {
    var options = Object.assign(overrides, defaultOptions);
    options.appId = $appId;
    options.appKey = $appKey;
    options.userId = $userId;
    options.url = $url
    return options;
}

// Text NLU
var options;
function textNlu(text){
    var options = createOptions({
        text: text,
        tag: $nluTag,
        language: $language
    });
    $nluExecute.prop('disabled', true);
    setTimeout(function t(){
        Nuance.startTextNLU(options);
    }, 1500)
}

// ASR / NLU

function asr(evt){
    if(isRecording) {
        Nuance.stopASR();
        $asrLabel.text('RECORD');
    } else {
        var options = createOptions({
            userMedia: userMedia,
            language: $language
        });

        if($useNlu.prop('checked')) {
            options.nlu = true;
            options.tag = $nluTag;
        }
        Nuance.startASR(options);
        $asrLabel.text('STOP RECORDING');
    }
    isRecording = !isRecording;
}
$asrRecord.on('click', asr);

// TTS

function tts(text){
    var options = createOptions({
        language: $language,
        voice: TTS_VOICE,
        text: text
    });
    Nuance.playTTS(options);
}

// ASR volume visualization

window.requestAnimFrame = (function(){
    return  window.requestAnimationFrame       ||
            window.webkitRequestAnimationFrame ||
            window.mozRequestAnimationFrame    ||
            function(callback, element){
                window.setTimeout(callback, 1000 / 60);
            };
})();



// Helpers

function setCredentialFields() {
    $url = localStorage.getItem("url") || URL || '';
    $appId = localStorage.getItem("app_id") || APP_ID || '';
    $appKey = localStorage.getItem("app_key") || APP_KEY || '';
    $userId = localStorage.getItem("user_id") || USER_ID || '';
    $nluTag = localStorage.getItem("nlu_tag") || NLU_TAG ||  '';
    $language = localStorage.getItem("language") || ASR_LANGUAGE || 'eng-USA';
}
setCredentialFields();

$saveCreds.on('click', function() {
    localStorage.setItem("url", $url);
    localStorage.setItem("app_id", $appId);
    localStorage.setItem("app_key", $appKey);
    localStorage.setItem("user_id", $userId);
    localStorage.setItem("nlu_tag", $nluTag);
    localStorage.setItem("language", $language);
    alert("Saved");
});
$resetCreds.on('click', function() {
    localStorage.setItem("url", URL);
    localStorage.setItem("app_id", APP_ID);
    localStorage.setItem("app_key", APP_KEY);
    localStorage.setItem("user_id", USER_ID);
    localStorage.setItem("nlu_tag", NLU_TAG);
    localStorage.setItem("language", ASR_LANGUAGE);
    setCredentialFields();
});

var dLog = function dLog(msg, logger, failure){
    var html = '<pre>'+msg+'</pre>';
    var time = new Date().toISOString();
    if(failure){
        html = '<span class="label label-danger">Error ('+time+')</span>' + html;
    } else {
        html = '<span class="label label-success">Success ('+time+')</span>' + html;
    }
    logger.prepend(html);
};

var LOG = function LOG(msg, type){
    var html = "<pre>"+JSON.stringify(msg, null, 2)+"</pre>";
    var time = new Date().toISOString();
    if(type === 'in'){
        html = '<span class="label label-info"><<<< Incoming (' + time + ')</span>' + html;
    } else {
        html = '<span class="label label-primary">>>>> Outgoing (' + time + ')</span>' + html;
    }
    $("#logs_output").prepend(html);
}
