var tab;
var recording = false;
//click button to record
chrome.browserAction.onClicked.addListener(function (tab2) {
  tab=tab2;
  chrome.tabs.sendMessage(tab.id, {text: 'rec'}, null);
});

function readFromCurrentLocation(){
  chrome.tabs.query(
        { currentWindow: true, active: true },
        function (tabArray) {
          chrome.tabs.sendMessage(tabArray[0].id, {text: 'get_selection_onward'}, null);
        }
    );
}

function readSelection(){
  chrome.tabs.query(
        { currentWindow: true, active: true },
        function (tabArray) {
          chrome.tabs.sendMessage(tabArray[0].id, {text: 'get_selected_text'}, null);
        }
    );
}

function readWholePage(){
  chrome.tabs.query(
        { currentWindow: true, active: true },
        function (tabArray) {
          chrome.tabs.sendMessage(tabArray[0].id, {text: 'get_page'}, null);
        }
    );
}


chrome.contextMenus.create({"title": "Start reading from here", "contexts":["selection"], "onclick": readFromCurrentLocation});
chrome.contextMenus.create({"title": "Read selection", "contexts":["selection"], "onclick": readSelection});
chrome.contextMenus.create({"title": "Read whole page", "contexts":["page"], "onclick": readWholePage});
