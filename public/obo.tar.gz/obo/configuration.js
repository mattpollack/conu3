// Credentials

var URL = 'wss://ws.dev.nuance.com/?';

var APP_ID = "NMDPTRIAL_michael_ian_wilson96_gmail_com20180127094600";
var APP_KEY = "6a9527386d2f4dfb51631f5e45a0781d1ddc652bec2a40ca276bc96eeb9db15532d88ea008db9b593ebab7835a30a0780c06a3f830e3c3574f8cc53a2976905c";
var USER_ID = "";
var NLU_TAG = "M10269_A3251";

// ASR
// See: https://developer.nuance.com/public/index.php?task=supportedLanguages
var ASR_LANGUAGE = "eng-USA";

// TTS
// See: https://developer.nuance.com/public/index.php?task=supportedLanguages
var TTS_LANGUAGE = "eng-USA";
var TTS_VOICE = "";