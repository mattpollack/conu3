function startReading(html) {
  var htmlObject = document.createElement('div');
  htmlObject.innerHTML = html;
  var myJson = addList(htmlObject.children);
  if(myJson.length == 0){
    setTimeout(function m(){tts("No text was found to speed read.");}, 250)
  }else{
  	console.log(myJson);
  	window.CONTEXT.read(myJson);
  	window.pr_manager.set(new Date(), window.CONTEXT.speed());
  }
}


function addList(children){
  var temp = [];
  var acceptedTags = ['P','H1','H2','H3','H4','H5','H6','SPAN','IMG','STRONG','A','B','CODE','CAPTION','DIALOG','EM','I','LABEL','LI','UL','OL','PRE','SPAN','TD','TH','VAR','U'];
  for(var i = 0; i<children.length; i++){
    if(children[i].tagName == 'DIV' || children[i].tagName == 'A'){
      temp = temp.concat(addList(children[i].children));
    }else {
      var helper = {};
      if(children[i].tagName == 'IMG'){
        helper[children[i].tagName]=children[i].src;
        //helper[children[i].tagName]=decodeURIComponent(children[i].src.replace("chrome-extension://","http://"));
      	temp.push(helper);
      }else if(acceptedTags.indexOf(children[i].tagName )!= -1){
      	var text = children[i].innerText.replace(/\s\s+/g, ' ').trim();
      	if(text != null && text.length > 0){
        	helper[children[i].tagName]=text;
      		temp.push(helper);
      	}
      }
    }
  }
  return temp;
}
$(document).ready(() => {
    

		    var date_string = (test) => {
			return [
			    test.getFullYear(),
			    test.getMonth(),
			    test.getDate(),
			    test.getHours(),
			    test.getMinutes(),
			    test.getSeconds(),
			].join(",");
		    };
    
	window.CONTEXT = new window.Context();
	window.pr_manager = (function() {
		// If saved is undefined that means the addon is not being run on the main page, and data must
		// be stored in chrome storage

		if (/* CLEAR ALL DATA IF TRUE */false) {
		    chrome.storage.sync.set({ stats: [] });
		    Cookies.set('stats', []);
		}
		else {
		    var $ = this;
		    var data;

		    if (window.Cookies)
			data = Cookies.getJSON("stats");

		    var cache = [];
		    chrome.storage.sync.get("stats", (_cache) => {
			_cache = _cache.stats;

			console.log("--above---");
			console.log(data);
			console.log(_cache);
			console.log("-------");

			if (data) {
			    data = data.concat(_cache);

			    Cookies.set('stats', data);

			    var flop = {}; flop[date_string(new Date())] = 250;
			    
			    chrome.storage.sync.set(
				{
				    stats: [_cache[_cache.length - 1] || flop]
				});
			}
			else {
			    cache = _cache;
			}

			if (cache && cache[0] == null)
			    cache = [];

			var speed = 
			    (data  && data.length  && data [0][Object.keys(data [0])[0]]) ||
			    (cache && cache.length && cache[0][Object.keys(cache[0])[0]]) || 250;
			
			window.CONTEXT.speed_set(speed);

			console.log("--below--");
			console.log(data);
			console.log(cache);
			console.log("-------");
		    });

		    $.set = (key, val) => {
			if (!val) return;
			
			val = parseInt(val);

			var t = {}; t[date_string(key)] = val;

			if (data) {
			    data.push(t);

			    Cookies.set('stats', data);
			}
			else {
			    console.log("HERE !!");
			    console.log(key, val);
			    console.log("H!");
			    console.log(t);

			    cache.push(t);
			    chrome.storage.sync.set({ stats: cache });
			}
		    };

		    $.get = () => {
			return data || cache;
		    };

		    return $;
		}
	    })();
})

$('div').contents().filter(function() {
  return this.nodeType === 3;
}).wrap('<p></p>').end();
$('body').contents().filter(function() {
  return this.nodeType === 3;
}).wrap('<p></p>').end();
$('p').each(function() {
    var $this = $(this);
    if($this.html().replace(/\s|&nbsp;/g, '').length == 0)
        $this.remove();
});
// Listen for messages
chrome.runtime.onMessage.addListener(function (msg, sender, sendResponse) {
	if (msg.text === 'console.log') {
    	console.log(msg.log);
    }else if(msg.text === 'rec') {
    	if(isRecording){
    		asr(null);
    	}else{
    		tts("Go");
    		setTimeout(rec, 500)
    	}
    }else if(msg.text === 'get_selection_onward') {
    	performFunction('read_until_end', startReading);
    }else if(msg.text === 'get_selected_text') {
    	performFunction('read_selection', startReading);
    }else if(msg.text === 'get_page') {
    	performFunction('read_full_page', startReading);
    }
});

function performFunction(name, sendResponse){
	if (name === 'read_full_page') {
        sendResponse(document.body.innerHTML);
    }else if (name === 'read_selection') {
    	var selection = getUserSelection();
    	if(selection.anchorNode == null){
    		  setTimeout(function m(){tts("No text was found to speed read.");}, 250)
    	}else{
    		var div = document.createElement('div');
			var div2 = document.createElement('p');
	        div2.appendChild( getRangeObject(getUserSelection()).cloneContents().cloneNode(true) );
	    	div.appendChild(div2);
	        sendResponse(div.innerHTML);
    	}
    }else if (name === 'read_until_end') {
        var selection = getUserSelection()
        if(selection.anchorNode == null){
        	sendResponse(document.body.innerHTML);
        }else{
	        var range = document.createRange();
				range.setStart(selection.anchorNode,selection.anchorOffset);
				range.setEnd(document.body,document.body.childNodes.length);
	        var div = document.createElement('div');
	        var div2 = document.createElement('p');
	        div2.appendChild(range.cloneContents().cloneNode(true))
			div.appendChild(div2);
	        sendResponse(div.innerHTML);
	    }
    }
}

function rec(){
	asr(null);
}

function getSelectedElement(){
	if (document.selection)
        return document.selection.createRange().parentElement();
    else
    {
        var selection = window.getSelection();
        if (selection.rangeCount > 0)
            return selection.getRangeAt(0).startContainer.parentNode;
    }
}

function getUserSelection(){
	if (window.getSelection) {
		return window.getSelection();
	}
	else if (document.selection) { // should come last; Opera!
		return document.selection.createRange();
	}
}
function getRangeObject(selectionObject) {
	if (selectionObject.getRangeAt)
		return selectionObject.getRangeAt(0);
	else {
		var range = document.createRange();
			range.setStart(selectionObject.anchorNode,selectionObject.anchorOffset);
			range.setEnd(selectionObject.focusNode,selectionObject.focusOffset);
		return range;
	}
}

function getPage(){

}

function setSelectedElements(){

}

function isSelectionBackwards() {
    var backwards = false;
    if (window.getSelection) {
        var sel = window.getSelection();
        if (!sel.isCollapsed) {
            var range = document.createRange();
            range.setStart(sel.anchorNode, sel.anchorOffset);
            range.setEnd(sel.focusNode, sel.focusOffset);
            backwards = range.collapsed;
            range.detach();
        }
    }
    return backwards;
}
