((window, document) => {
    /* NOTES:
       Creates a flash reading context in a fixed and centered
       position on the page. Background content is faded out
       and a box appears with player options.

       Considerations:
       - Content awareness/intrusion
    */

    var $B = (type, keys, fn) => {
	var res = document.createElement(type || "div");

	if (keys)
	    Object.keys(keys).map((k) => res[k] = keys[k]);

	if (fn)
	    fn(res);

	return res;
    };

    function Context() {
	var $ = this;
	var pref = {
	    speed: 200,
	    group: 1,
	};

	var el =
	    $B("div", { className: "pr_base" },
	       (base) => [
		   /**
		    * NAVIGATION BAR
		    */
		   $B("div", { className: "pr_nav" }, (e) => {
		       base.nav = e;
		       e.render = (state, current) => {
			   // Clear
			   e.innerHTML = "";
			   // TODO: Add title
			   current.nav
			   // Create each nav button
			       .map((page_id) =>
				    $B("div", { className: "pr_nav_button" },
				       (button) => {
					   if (state.pages[page_id].icon)
					       button.innerHTML = "<img src=\"" + state.pages[page_id].icon + "\"></img>";
					   else
					       button.innerHTML = "X";
					   
					   button.onclick = function () {
					       state.history = [page_id].concat(state.history);
					       $.render();
					   }.bind({ page_id });
				       }))
			   // Add default back button
			       .concat(
				   $B("div", { className: "pr_nav_back" },
				      (button) => {
				      button.innerHTML = "<img src=\"" + chrome.extension.getURL("back.png") + "\"></img>";
					  button.onclick = function() {
					      if (state.history.length > 1) {
						  state.history = state.history.slice(1);
						  $.render();
					      }
					  };
				      }))
			   // Add each button to nav bar
			       .map((b) => e.appendChild(b));
		       };
		   }),

		   /**
		    * BODY SECTION
		    */
		   $B("div", { className: "pr_body" }, (e) => {
		       base.body = e;
		       e.render = (state, current) => {
			   e.innerHTML = "";
			   current.render(e);
		       };
		   }),
	       ].map((d) => base.appendChild(d)));

	var state = {
	    history: [0],
	    pages: [
		{
		    title: "Home",
		    icon: undefined,  // icon href
		    nav: [1],
		    render: (ctx) =>
			[
			    /**
			     * Current word for display
			     */
			    $B("div", { id: "pr_body_word" }, (word) => {
				el.word = { render: () => {
				    word.innerHTML = state.src[state.i] || "";
				}};
				word.innerHTML = state.src[state.i] || "";
			    }),

			    /**
			     * Player
			     */
			    $B("div", { id: "pr_body_player" }, (player) => {
				[
				    $B("div", {
					id: "pr_body_button_prev",
					onclick: $.prev = () => {
					    state.i = 0;
					    state.playing = false;

					    $.render();
					},
				    }, (prev) => {
					prev.innerHTML = "<img src=\""+ chrome.extension.getURL("prev.png") +"\"></img>";
				    }),
				    $B("div", {
					id: "pr_body_button_play",
					onclick: $.play = () => {
					    if (!state.src || state.src.length == 0)
						return;
					    
					    state.last = Date.now();
					    state.playing = !state.playing;

					    window.pr_manager.set(new Date(), pref.speed);

					    $.render();
					},
				    }, (play) => {
					play.innerHTML = "<img src=\""+
					    (state.playing ?
					     chrome.extension.getURL("pause.png") :
					     chrome.extension.getURL("play.png")) +"\"></img>";
				    }),
				    $B("div", {
					id: "pr_body_button_next",
					onclick: $.next = () => console.log("next"),
				    }, (prev) => {
					prev.innerHTML = "<img src=\""+ chrome.extension.getURL("next.png") +"\"></img>";
					prev.style.visibility = "hidden";
				    }),
				].map((e) => player.appendChild(e));
			    }),
			].map((p) => ctx.appendChild(p)),
		},
		{
		    title: "Settings",
		    icon: chrome.extension.getURL("settings.png"),  // icon href
		    nav: [],
		    render: (ctx) =>
			[
			    $B("div", {}, (speed) => {
				ctx.speed = speed;
				speed.innerHTML = pref.speed + " wpm";
			    }),
			    $B("input", {
				type: "range",
				min: 1,
				max: 1000,
				value: pref.speed
			    }, (speed) => {
				speed.oninput = () => {
				    pref.speed = speed.value;
				    ctx.speed.innerHTML = pref.speed + " wpm";
				};
			    }),
			    $B("div", {}, (l) => {
				l.innerHTML = "<a href=\"http://proread.tech:8081/\">Analytics</a>";
			    }),
			].map((p) => ctx.appendChild(p)),
		},
	    ],
	    src: [],
	    last: undefined,
	    i: 0,
	    playing: false,
	};

	$.render = () => {
	    var current = state.pages[state.history[0]] || {
		title: "ERROR",
		icon: undefined,
		nav: [],
		render: (ctx) => {
		    ctx.innerHTML = "ERROR: what even";
		}
	    };
	    el.nav.render(state, current);
	    el.body.render(state, current);
	};

	$.hide = () => {
	    el.style.display = "none";
	};
	$.speed = () => {		
	    return pref.speed;		
	};
	$.speed_set = (x) => {
	    pref.speed = x;
	};
	$.show = () => {
	    el.style.display = "";
	};
	$.hide();

	$.showing = () => {
		return el.style.display != "none";
	}

	$.settings = () => {
	    state.history = [1].concat(state.history);
	    $.show();
	    $.render();
	};

	$.read = (src) => {
	    state.history = [0].concat(state.history);
	    $.show();
	    state.src = [];
	    state.i = 0;
	    state.last = Date.now();

	    src.map(
		(each) => {
		    if (Object.keys(each)[0].toLowerCase() != "img")
			each[Object.keys(each)[0]]
			.split(/\s/)
			.map((word) => state.src.push(word))
		});

	    $.play();
	};

	window.setInterval(() => {
	    if (state.playing) {
		const now = Date.now();

		if (now - state.last >= 60*1000/pref.speed) {
		    ++state.i;

		    if (state.i > state.src.length)
			state.playing = false;

		    state.last = now;

		    //$.render();
		    el.word.render();
		}
	    }
	}, 0);

	// Deploy
	$.render();
	document.body.appendChild(el);
    }

    window.Context = Context;
})
(
    window,
    document
);
